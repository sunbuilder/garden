var type =[{
  "type": "全部"
}, {
    "type": "多肉植物"
  }, {
    "type": "观赏植物"
  }, {
    "type": "观叶植物"
  }, {
    "type": "草本植物"
  }, {
    "type": "木本植物"
  }, {
    "type": "水生植物"
  }, {
    "type": "水培植物"
  }, {
    "type": "其他"
  }
]


module.exports={
  type:type
}