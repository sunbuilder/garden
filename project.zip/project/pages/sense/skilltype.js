var type =[{
  "type": "全部"
}, {
    "type": "多肉植物"
  }, {
    "type": "观赏植物"
  }, {
    "type": "草本植物"
  }, {
    "type": "木本植物"
  }
]


module.exports={
  type:type
}